// ─── Language data ────────────────────────────────────────────────────────────

const LANG_MAP = {
  'pt':'Português','pt-br':'Português (BR)','pt-pt':'Português (PT)',
  'en':'English','en-us':'English (US)','en-gb':'English (UK)',
  'es':'Español','fr':'Français','de':'Deutsch','it':'Italiano',
  'nl':'Nederlands','pl':'Polski','ru':'Русский','uk':'Українська',
  'ar':'العربية','zh':'中文','zh-cn':'中文 (简体)','zh-tw':'中文 (繁體)',
  'ja':'日本語','ko':'한국어','hi':'हिन्दी','th':'ภาษาไทย',
  'tr':'Türkçe','sv':'Svenska','da':'Dansk','fi':'Suomi','nb':'Norsk',
  'he':'עברית','el':'Ελληνικά','cs':'Čeština','ro':'Română',
  'hu':'Magyar','sk':'Slovenčina','bg':'Български','hr':'Hrvatski',
  'ca':'Català','id':'Bahasa Indonesia','ms':'Bahasa Melayu','vi':'Tiếng Việt',
};

const SCRIPT_COLORS = { latin:'#7B6EF6',cyrillic:'#FF5E5E',arabic:'#FFB547',cjk:'#3FFFA2',hangul:'#5EC4FF',hebrew:'#FF8C69',devanagari:'#FF6B9D',thai:'#A8E6CF',greek:'#DDA0DD' };
const SCRIPT_LABELS = { latin:'Latino',cyrillic:'Cirílico',arabic:'Árabe',cjk:'CJK (Chin/Jap)',hangul:'Hangul (Cor)',hebrew:'Hebraico',devanagari:'Devanagari',thai:'Tailandês',greek:'Grego' };

// Common word lists per language for foreign-word heuristic
const COMMON_WORDS = {
  pt: new Set(['de','a','o','que','e','do','da','em','um','para','com','uma','os','no','se','na','por','mais','as','dos','como','mas','ao','ele','das','seu','sua','ou','ser','quando','muito','há','nos','já','está','também','só','pelo','pela','até','isso','ela','entre','era','depois','sem','mesmo','aos','ter','seus','quem','nas','me','esse','eles','estão','você','tinha','foram','essa','num','nem','suas','meu','às','minha','têm','numa','pelos','pelas','este','fosse','dele','tu','te','vocês','nós','vos','lhe','lhes','meus','teu','tua','teus','tuas','nosso','nossa','nossos','nossas','deste','desta','neste','nesta','nesse','nessa','desse','dessa','isto','aqui','tudo','todos','todo','toda','todas']),
  en: new Set(['the','be','to','of','and','a','in','that','have','it','for','not','on','with','he','as','you','do','at','this','but','his','by','from','they','we','say','her','she','or','an','will','my','one','all','would','there','their','what','so','up','out','if','about','who','get','which','go','me','when','make','can','like','time','no','just','him','know','take','people','into','year','your','good','some','could','them','see','other','than','then','now','look','only','come','its','over','think','also','back','after','use','two','how','our','work','first','well','way','even','new','want','because','any','these','give','most','us']),
  es: new Set(['de','la','que','el','en','y','a','los','del','se','las','un','por','con','no','una','su','para','es','al','lo','como','más','pero','sus','le','ya','o','fue','este','ha','sí','porque','esta','entre','cuando','muy','sin','sobre','ser','tiene','también','me','hasta','hay','donde','han','quien','están','estado','desde','todo','nos','durante','estados','todos','uno','les','ni','contra','otros','ese','eso','ante','ellos','e','esto','mí','antes','algunos','qué','unos','yo','otro','otras','otra','él','tanto','esa','estos','mucho','quienes','nada','muchos','cual','poco','ella','estar','estas','algunas','algo','nosotros']),
  fr: new Set(['le','la','les','de','du','des','un','une','et','en','au','aux','je','tu','il','elle','nous','vous','ils','elles','ce','qui','que','quoi','dont','où','ne','pas','plus','par','sur','dans','avec','sans','sous','entre','vers','chez','est','sont','être','avoir','faire','pouvoir','vouloir','aller','voir','savoir','prendre','venir','tout','tous','toute','toutes','mon','ma','mes','ton','ta','tes','son','sa','ses','notre','votre','leur','leurs','cet','cette','ces','même','comme','mais','ou','donc','or','ni','car','si','bien','très','aussi','alors','encore','déjà','toujours','jamais','souvent','parfois']),
  de: new Set(['der','die','das','des','dem','den','ein','eine','einer','einem','einen','und','in','ist','von','zu','mit','sich','auf','für','im','nicht','an','als','auch','es','an','bei','nach','noch','war','so','aus','durch','wird','aber','wird','haben','ihre','seiner','seine','nur','um','über','man','sie','zwei','kann','doch','vor','dieser','mich','ihn','uns','mir','wir','ihn','sie','ja','eine','sein','haben','dieser','oder','habe','ihre','wir','dort','wo','wenn','dann','mehr','was','wer','wie','alle','schon','beim','zum']),
  it: new Set(['di','il','la','che','e','in','un','è','non','del','una','per','con','dei','le','si','da','lo','dei','nel','ha','ho','mi','su','al','sono','ci','più','se','ma','questo','anche','delle','nella','agli','alla','come','quella','quello','tra','gli','quando','lui','lei','noi','voi','loro','mio','mia','miei','mie','tuo','tua','tuoi','tue','suo','sua','suoi','sue','nostro','nostra','nostri','nostre','vostro','vostra','vostri','vostre']),
};

// Script detection per language code
const LANG_SCRIPT = {
  ru:'cyrillic',uk:'cyrillic',bg:'cyrillic',
  ar:'arabic',he:'hebrew',hi:'devanagari',
  th:'thai',el:'greek',zh:'cjk',ja:'cjk',ko:'hangul',
};

// ─── Page scan function (injected into tab) ───────────────────────────────────

function pageScanFn() {
  function pct(n,total){ return Math.round((n/total)*100); }
  function analyzeCharacters(text){
    const s=text.slice(0,2000);
    let latin=0,cyrillic=0,arabic=0,cjk=0,hangul=0,hebrew=0,devanagari=0,thai=0,greek=0,other=0;
    for(const ch of s){
      const cp=ch.codePointAt(0);
      if((cp>=0x41&&cp<=0x7A)||(cp>=0xC0&&cp<=0x24F))latin++;
      else if(cp>=0x400&&cp<=0x4FF)cyrillic++;
      else if(cp>=0x600&&cp<=0x6FF)arabic++;
      else if((cp>=0x4E00&&cp<=0x9FFF)||(cp>=0x3040&&cp<=0x30FF))cjk++;
      else if(cp>=0xAC00&&cp<=0xD7AF)hangul++;
      else if(cp>=0x590&&cp<=0x5FF)hebrew++;
      else if(cp>=0x900&&cp<=0x97F)devanagari++;
      else if(cp>=0xE00&&cp<=0xE7F)thai++;
      else if(cp>=0x370&&cp<=0x3FF)greek++;
      else if(ch.trim().length>0)other++;
    }
    const total=latin+cyrillic+arabic+cjk+hangul+hebrew+devanagari+thai+greek+other||1;
    return{latin:pct(latin,total),cyrillic:pct(cyrillic,total),arabic:pct(arabic,total),cjk:pct(cjk,total),hangul:pct(hangul,total),hebrew:pct(hebrew,total),devanagari:pct(devanagari,total),thai:pct(thai,total),greek:pct(greek,total)};
  }
  function extractMainText(){
    const skip=new Set(['script','style','noscript','svg','head','nav','footer','iframe']);
    const walker=document.createTreeWalker(document.body||document.documentElement,NodeFilter.SHOW_TEXT,{acceptNode(node){let el=node.parentElement;while(el){if(skip.has(el.tagName.toLowerCase()))return NodeFilter.FILTER_REJECT;el=el.parentElement;}return node.textContent.trim().length>3?NodeFilter.FILTER_ACCEPT:NodeFilter.FILTER_SKIP;}});
    let text='',node;
    while((node=walker.nextNode())&&text.length<5000)text+=' '+node.textContent.trim();
    return text.trim();
  }
  const bodyText=extractMainText();
  const charStats=analyzeCharacters(bodyText);
  const entries=Object.entries(charStats).sort((a,b)=>b[1]-a[1]);
  const detectedScript=entries[0][1]>5?entries[0][0]:'latin';
  return{
    htmlLang:document.documentElement.lang||null,
    metaLang:document.querySelector('meta[http-equiv="content-language"]')?.content||null,
    ogLocale:document.querySelector('meta[property="og:locale"]')?.content||null,
    detectedScript,charStats,
    wordCount:bodyText.trim().split(/\s+/).filter(w=>w.length>0).length,
    charCount:bodyText.replace(/\s/g,'').length,
    selectedText:window.getSelection()?.toString().trim()||null,
    pageTitle:document.title,
    pageUrl:window.location.href,
    bodyText:bodyText.slice(0,8000)
  };
}

// ─── Highlight inject/clear functions ─────────────────────────────────────────

function injectHighlightsFn(foreignWords) {
  const MARKER = 'langscan-hl';
  // Remove existing
  document.querySelectorAll('.' + MARKER).forEach(el => {
    el.replaceWith(document.createTextNode(el.textContent));
  });
  if (!foreignWords || foreignWords.length === 0) return 0;

  const wordSet = new Set(foreignWords.map(w => w.toLowerCase()));
  const skip = new Set(['script','style','noscript','svg','head','nav','footer','iframe','input','textarea']);
  let count = 0;

  function walkAndHighlight(root) {
    const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
      acceptNode(node) {
        let el = node.parentElement;
        if (el && el.classList.contains(MARKER)) return NodeFilter.FILTER_REJECT;
        while (el) {
          if (skip.has(el.tagName.toLowerCase())) return NodeFilter.FILTER_REJECT;
          el = el.parentElement;
        }
        return node.textContent.trim().length > 0 ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_SKIP;
      }
    });

    const nodes = [];
    let node;
    while ((node = walker.nextNode())) nodes.push(node);

    for (const textNode of nodes) {
      const text = textNode.textContent;
      const regex = new RegExp('\\b(' + foreignWords.map(w => w.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')).join('|') + ')\\b', 'gi');
      if (!regex.test(text)) continue;
      regex.lastIndex = 0;

      const frag = document.createDocumentFragment();
      let last = 0, match;
      while ((match = regex.exec(text)) !== null) {
        if (match.index > last) frag.appendChild(document.createTextNode(text.slice(last, match.index)));
        const span = document.createElement('span');
        span.className = MARKER;
        span.textContent = match[0];
        span.style.cssText = 'background:#FFB547 !important;color:#1A1000 !important;border-radius:3px !important;padding:0 2px !important;font-weight:600 !important;outline:2px solid rgba(255,181,71,0.5) !important;';
        span.title = 'Palavra estrangeira detectada pelo LangScan';
        frag.appendChild(span);
        count++;
        last = match.index + match[0].length;
      }
      if (last < text.length) frag.appendChild(document.createTextNode(text.slice(last)));
      textNode.parentNode.replaceChild(frag, textNode);
    }
  }

  walkAndHighlight(document.body || document.documentElement);
  return count;
}

function clearHighlightsFn() {
  const MARKER = 'langscan-hl';
  document.querySelectorAll('.' + MARKER).forEach(el => {
    el.replaceWith(document.createTextNode(el.textContent));
  });
}

// ─── Language resolution ──────────────────────────────────────────────────────

function resolveLanguage(data, selectedLang) {
  if (selectedLang && selectedLang !== 'auto') {
    const name = LANG_MAP[selectedLang] || selectedLang.toUpperCase();
    return { name, code: selectedLang, confidence: 95, sources: [{ source: 'selecionado', confidence: 95 }] };
  }

  const candidates = [];
  const declared = [data.htmlLang, data.metaLang, data.ogLocale]
    .filter(Boolean).map(l => l.toLowerCase().replace('_','-').trim());

  for (const lang of declared) {
    const base = lang.split('-')[0];
    if (LANG_MAP[lang] || LANG_MAP[base]) candidates.push({ lang, source: 'html/meta', confidence: 88 });
  }

  const script = data.detectedScript;
  const scriptLangMap = { cyrillic:'ru', arabic:'ar', hebrew:'he', devanagari:'hi', thai:'th', greek:'el', cjk:'zh', hangul:'ko' };
  if (scriptLangMap[script] && !candidates.some(c => c.lang.startsWith(scriptLangMap[script]))) {
    candidates.push({ lang: scriptLangMap[script], source: 'escrita', confidence: 72 });
  }

  if (candidates.length === 0) candidates.push({ lang:'en', source:'padrão', confidence: 40 });

  const best = candidates[0];
  const shortLang = best.lang.split('-')[0];
  const name = LANG_MAP[best.lang] || LANG_MAP[shortLang] || best.lang.toUpperCase();
  let conf = best.confidence;
  if (data.htmlLang && data.detectedScript) conf = Math.min(conf + 5, 97);

  return { name, code: shortLang, confidence: conf, sources: candidates };
}

// ─── Foreign word detection ───────────────────────────────────────────────────

function detectForeignWords(bodyText, baseLang) {
  // For non-latin script languages, skip word-level detection
  if (LANG_SCRIPT[baseLang]) return [];

  const knownWords = COMMON_WORDS[baseLang];
  if (!knownWords) return [];

  // Extract all latin words from the text
  const allWords = bodyText.match(/\b[a-zA-ZÀ-ÿ]{3,}\b/g) || [];
  const freq = {};
  for (const w of allWords) {
    const lw = w.toLowerCase();
    freq[lw] = (freq[lw] || 0) + 1;
  }

  // Words not in the base language's common word list
  // and that appear in at least one other language's common words
  const otherLangs = Object.keys(COMMON_WORDS).filter(l => l !== baseLang);
  const foreignWords = [];

  for (const [word, count] of Object.entries(freq)) {
    if (knownWords.has(word)) continue;
    if (word.length < 3) continue;

    // Check if it looks like a proper noun (skip) or URL fragment (skip)
    if (/^\d+$/.test(word)) continue;

    // Check if it exists in another language's common list
    const foundIn = otherLangs.filter(l => COMMON_WORDS[l].has(word));
    if (foundIn.length > 0) {
      foreignWords.push({ word, count, langs: foundIn });
    }
  }

  // Sort by frequency descending, limit to top 40
  return foreignWords.sort((a,b) => b.count - a.count).slice(0, 40);
}

// ─── UI helpers ───────────────────────────────────────────────────────────────

function showState(state) {
  document.getElementById('idleState').style.display = state === 'idle' ? 'block' : 'none';
  document.getElementById('loadingState').style.display = state === 'loading' ? 'block' : 'none';
  document.getElementById('errorState').style.display = state === 'error' ? 'block' : 'none';
  const res = document.getElementById('resultState');
  state === 'result' ? res.classList.add('show') : res.classList.remove('show');
}

function renderSources(sources) {
  const row = document.getElementById('sourcesRow');
  row.innerHTML = '';
  const seen = new Set();
  for (const s of sources) {
    if (seen.has(s.source)) continue;
    seen.add(s.source);
    const tag = document.createElement('span');
    tag.className = 'source-tag ' + (s.confidence >= 80 ? 'match' : 'neutral');
    tag.textContent = s.source;
    row.appendChild(tag);
  }
}

function renderScripts(stats) {
  const container = document.getElementById('scriptBars');
  container.innerHTML = '';
  const entries = Object.entries(stats).filter(([,v]) => v > 0).sort((a,b) => b[1]-a[1]);
  if (!entries.length) { container.innerHTML = '<p style="font-size:11px;color:var(--muted)">Sem dados.</p>'; return; }
  for (const [key, pct] of entries) {
    const row = document.createElement('div');
    row.className = 'script-row';
    row.innerHTML = `<span class="script-name">${SCRIPT_LABELS[key]||key}</span><div class="script-bar-wrap"><div class="script-bar" data-pct="${pct}" style="background:${SCRIPT_COLORS[key]||'#7B6EF6'}"></div></div><span class="script-pct">${pct}%</span>`;
    container.appendChild(row);
  }
  requestAnimationFrame(() => {
    document.querySelectorAll('.script-bar').forEach(b => { b.style.width = b.dataset.pct + '%'; });
  });
}

function renderHighlightSection(foreignWords, baseLang) {
  const section = document.getElementById('highlightSection');
  const summary = document.getElementById('highlightSummary');
  const list = document.getElementById('foreignWordsList');
  const clearBtn = document.getElementById('clearBtn');

  section.style.display = 'block';
  list.innerHTML = '';

  if (LANG_SCRIPT[baseLang]) {
    summary.innerHTML = `<div class="hl-dot" style="background:var(--muted)"></div><p style="color:var(--muted)">Detecção de palavras estrangeiras disponível apenas para idiomas latinos.</p>`;
    document.getElementById('highlightToggle').disabled = true;
    return;
  }

  if (!COMMON_WORDS[baseLang]) {
    summary.innerHTML = `<div class="hl-dot" style="background:var(--muted)"></div><p style="color:var(--muted)">Banco de palavras não disponível para este idioma ainda.</p>`;
    document.getElementById('highlightToggle').disabled = true;
    return;
  }

  document.getElementById('highlightToggle').disabled = false;

  if (foreignWords.length === 0) {
    summary.innerHTML = `<div class="hl-dot" style="background:var(--green)"></div><p><strong class="color-green">Nenhuma palavra estrangeira</strong> detectada. O texto parece uniforme.</p>`;
    clearBtn.style.display = 'none';
  } else {
    summary.innerHTML = `<div class="hl-dot" style="background:var(--amber)"></div><p><strong class="color-amber">${foreignWords.length} palavras</strong> em outro idioma encontradas na página.</p>`;
    for (const { word } of foreignWords) {
      const tag = document.createElement('span');
      tag.className = 'word-tag';
      tag.textContent = word;
      list.appendChild(tag);
    }
  }
}

// ─── Main scan ────────────────────────────────────────────────────────────────

let lastTabId = null;
let lastForeignWords = [];
let lastBaseLang = 'en';

async function scan() {
  const btn = document.getElementById('scanBtn');
  btn.disabled = true;
  btn.textContent = '…';
  document.getElementById('highlightToggle').checked = false;
  document.getElementById('clearBtn').style.display = 'none';
  showState('loading');

  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab?.id) throw new Error('Aba não acessível.');
    lastTabId = tab.id;

    const results = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: pageScanFn
    });

    const data = results?.[0]?.result;
    if (!data) throw new Error('Não foi possível escanear esta página.');

    const selectedLang = document.getElementById('langSelect').value;
    const lang = resolveLanguage(data, selectedLang);
    lastBaseLang = lang.code;

    // Detect foreign words
    const foreignWords = detectForeignWords(data.bodyText || '', lang.code);
    lastForeignWords = foreignWords.map(fw => fw.word);

    // Render
    document.getElementById('pageTitle').textContent = data.pageTitle || data.pageUrl || '(sem título)';
    document.getElementById('langName').textContent = lang.name;
    document.getElementById('langCode').textContent = lang.code;

    const confBar = document.getElementById('confBar');
    confBar.style.width = '0%';
    document.getElementById('confPct').textContent = lang.confidence + '%';
    setTimeout(() => { confBar.style.width = lang.confidence + '%'; }, 80);

    renderSources(lang.sources);
    document.getElementById('wordCount').textContent = (data.wordCount || 0).toLocaleString('pt-BR');
    document.getElementById('charCount').textContent = (data.charCount || 0).toLocaleString('pt-BR');
    renderHighlightSection(foreignWords, lang.code);
    renderScripts(data.charStats);

    showState('result');

  } catch (err) {
    let msg = err.message || 'Erro desconhecido.';
    if (msg.includes('Cannot access') || msg.includes('chrome://')) {
      msg = 'Esta página não pode ser acessada.\nTente em um site normal (ex: wikipedia.org).';
    }
    document.getElementById('errorMsg').textContent = msg;
    showState('error');
  } finally {
    btn.disabled = false;
    btn.textContent = 'Escanear';
  }
}

// ─── Highlight toggle ─────────────────────────────────────────────────────────

document.getElementById('highlightToggle').addEventListener('change', async (e) => {
  const clearBtn = document.getElementById('clearBtn');
  if (!lastTabId) return;

  if (e.target.checked) {
    if (lastForeignWords.length === 0) return;
    await chrome.scripting.executeScript({
      target: { tabId: lastTabId },
      func: injectHighlightsFn,
      args: [lastForeignWords]
    });
    clearBtn.style.display = 'block';
  } else {
    await chrome.scripting.executeScript({
      target: { tabId: lastTabId },
      func: clearHighlightsFn
    });
    clearBtn.style.display = 'none';
  }
});

document.getElementById('clearBtn').addEventListener('click', async () => {
  if (!lastTabId) return;
  await chrome.scripting.executeScript({ target: { tabId: lastTabId }, func: clearHighlightsFn });
  document.getElementById('highlightToggle').checked = false;
  document.getElementById('clearBtn').style.display = 'none';
});

// ─── Init ─────────────────────────────────────────────────────────────────────

document.getElementById('scanBtn').addEventListener('click', scan);
document.addEventListener('DOMContentLoaded', scan);
